
import React from 'react';
import { useParams } from 'react-router-dom';
import { posts } from '../data/posts';
import PostCard from '../components/PostCard';
import AdPlaceholder from '../components/AdPlaceholder';

const CategoryPage: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const filteredPosts = posts.filter(p => p.category === category);

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-black text-gray-900 mb-4">قسم: {category}</h1>
        <p className="text-gray-500">اكتشف أحدث المقالات والنصائح في مجال {category}</p>
      </div>

      <div className="mb-12">
        <AdPlaceholder size="banner" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredPosts.length > 0 ? (
          filteredPosts.map(post => (
            <PostCard key={post.id} post={post} />
          ))
        ) : (
          <div className="col-span-full py-20 text-center">
            <p className="text-gray-500 text-xl">لا توجد مقالات حالياً في هذا القسم.</p>
          </div>
        )}
      </div>

      <div className="mt-12">
        <AdPlaceholder size="banner" label="إعلان أسفل القائمة" />
      </div>
    </div>
  );
};

export default CategoryPage;
