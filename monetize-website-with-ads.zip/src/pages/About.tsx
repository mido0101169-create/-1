
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-16 max-w-4xl">
      <h1 className="text-4xl font-black text-gray-900 mb-8 text-center">من نحن</h1>
      <div className="prose prose-lg max-w-none text-gray-700 leading-loose">
        <p>
          مرحبًا بكم في <strong>بوابة المعرفة</strong>، المنصة العربية الرائدة التي تهدف إلى تمكين الشباب العربي في المجالات التقنية وريادة الأعمال الرقمية.
        </p>
        <p>
          تأسست هذه المدونة في عام 2024 لسد الفجوة في المحتوى العربي المتخصص في طرق الربح الحقيقي من الإنترنت، وتقديم شروحات مبسطة وعملية للتقنيات الحديثة.
        </p>
        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">رؤيتنا</h2>
        <p>
          نطمح لأن نكون المصدر الأول والموثوق لكل شاب عربي يبحث عن فرصة لتطوير مهاراته أو بدء مشروعه الخاص على شبكة الإنترنت.
        </p>
        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">ماذا نقدم؟</h2>
        <ul>
          <li>دروس شاملة في البرمجة وتطوير المواقع.</li>
          <li>استراتيجيات مجربة للربح من جوجل أدسينس والدروبشيبينغ.</li>
          <li>أحدث أخبار الذكاء الاصطناعي وكيفية الاستفادة منه.</li>
          <li>دليل شامل لتحسين محركات البحث (SEO).</li>
        </ul>
      </div>
    </div>
  );
};

export default About;
