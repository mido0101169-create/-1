
import React from 'react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-16 max-w-4xl">
      <h1 className="text-4xl font-black text-gray-900 mb-8 text-center">سياسة الخصوصية</h1>
      <div className="prose prose-lg max-w-none text-gray-700 leading-loose">
        <p>في "بوابة المعرفة"، نولي أهمية قصوى لخصوصية زوارنا. توضح وثيقة سياسة الخصوصية هذه أنواع المعلومات الشخصية التي نجمعها وكيفية استخدامها.</p>
        
        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">ملفات السجل (Log Files)</h2>
        <p>مثل العديد من المواقع الأخرى، يستخدم موقعنا ملفات السجل. تتضمن المعلومات داخل هذه الملفات عناوين بروتوكول الإنترنت (IP)، نوع المتصفح، مزود خدمة الإنترنت (ISP)، طابع التاريخ/الوقت، وصفحات الإحالة/الخروج.</p>
        
        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">ملفات تعريف الارتباط (Cookies)</h2>
        <p>نحن نستخدم ملفات تعريف الارتباط لتخزين معلومات حول تفضيلات الزوار، ولتخصيص محتوى صفحة الويب بناءً على نوع متصفح الزوار أو معلومات أخرى يرسلها الزائر عبر المتصفح.</p>
        
        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">سهم جوجل أدسينس (Google AdSense)</h2>
        <p>تستخدم جوجل، كطرف ثالث، ملفات تعريف الارتباط لعرض الإعلانات على موقعنا. استخدام جوجل لملف تعريف الارتباط DART يمهد لها عرض الإعلانات للمستخدمين استناداً إلى زياراتهم لموقعنا ومواقع أخرى على الإنترنت.</p>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
