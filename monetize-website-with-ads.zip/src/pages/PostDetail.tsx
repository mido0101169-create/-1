
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { posts } from '../data/posts';
import { Calendar, User, Share2, MessageCircle, Bookmark, ArrowRight } from 'lucide-react';
import AdPlaceholder from '../components/AdPlaceholder';

const PostDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const post = posts.find(p => p.id === id);

  if (!post) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <h1 className="text-3xl font-bold mb-4">عذراً، المقال غير موجود</h1>
        <Link to="/" className="text-blue-600 hover:underline">العودة للرئيسية</Link>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Article Header */}
      <div className="container mx-auto px-4 pt-12">
        <div className="max-w-4xl mx-auto">
          <Link to="/" className="inline-flex items-center gap-2 text-blue-600 font-bold mb-8 hover:gap-3 transition-all">
            <ArrowRight className="w-4 h-4" /> العودة للرئيسية
          </Link>
          
          <span className="inline-block px-4 py-1.5 bg-blue-50 text-blue-700 text-sm font-bold rounded-full mb-6">
            {post.category}
          </span>
          
          <h1 className="text-3xl md:text-5xl font-black text-gray-900 mb-8 leading-tight">
            {post.title}
          </h1>

          <div className="flex flex-wrap items-center justify-between gap-6 pb-12 border-b border-gray-100">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-gray-500">
                <User className="w-6 h-6" />
              </div>
              <div>
                <p className="font-bold text-gray-900">{post.author}</p>
                <p className="text-sm text-gray-500 flex items-center gap-2">
                  <Calendar className="w-4 h-4" /> {post.date}
                </p>
              </div>
            </div>
            
            <div className="flex gap-3">
              <button className="p-3 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors text-gray-600">
                <Share2 className="w-5 h-5" />
              </button>
              <button className="p-3 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors text-gray-600">
                <Bookmark className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Main Image */}
          <div className="rounded-[2.5rem] overflow-hidden mb-12 shadow-2xl">
            <img src={post.image} alt={post.title} className="w-full h-auto object-cover max-h-[500px]" />
          </div>

          <div className="flex flex-col lg:flex-row gap-12">
            {/* Content */}
            <div className="flex-1 min-w-0">
              <article className="prose prose-lg prose-blue max-w-none text-gray-700 leading-loose text-right">
                <p className="text-xl font-medium text-gray-900 mb-8 leading-relaxed">
                  {post.excerpt}
                </p>

                <AdPlaceholder size="banner" label="إعلان بداية المقال" />
                
                <div className="mt-8">
                  {post.content}
                  <p className="mt-6">
                    هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.
                  </p>
                  <p className="mt-6">
                    إذا كنت تبحث عن كيفية الربح من الإنترنت فعليك التركيز على بناء محتوى ذو قيمة عالية للجمهور، لأن جوجل تهتم بالمحتوى الذي يقدم حلولاً حقيقية للمستخدمين.
                  </p>
                </div>

                <div className="my-12">
                  <AdPlaceholder size="banner" label="إعلان منتصف المقال" />
                </div>

                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-900">نصائح هامة للنجاح:</h2>
                  <ul className="list-disc list-inside space-y-3">
                    <li>الاستمرارية هي مفتاح النجاح في التدوين.</li>
                    <li>اهتم بتحسين محركات البحث (SEO).</li>
                    <li>قدم محتوى حصري وغير منسوخ.</li>
                    <li>تفاعل مع تعليقات الزوار.</li>
                  </ul>
                </div>
              </article>

              {/* Author Bio */}
              <div className="mt-16 p-8 bg-gray-50 rounded-[2rem] border border-gray-100 flex flex-col md:flex-row items-center gap-8">
                <div className="w-24 h-24 bg-blue-100 rounded-full flex-shrink-0 flex items-center justify-center text-blue-600 font-bold text-3xl">
                  {post.author[0]}
                </div>
                <div className="text-center md:text-right">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">عن الكاتب: {post.author}</h4>
                  <p className="text-gray-500 text-sm leading-relaxed">
                    متخصص في كتابة المحتوى التقني ومقالات الربح من الإنترنت، يعمل في هذا المجال منذ أكثر من 5 سنوات ويهدف إلى مساعدة الشباب العربي على النجاح في العالم الرقمي.
                  </p>
                </div>
              </div>

              {/* Comments Placeholder */}
              <div className="mt-16">
                <div className="flex items-center gap-2 mb-8">
                  <MessageCircle className="w-6 h-6 text-blue-600" />
                  <h3 className="text-2xl font-bold text-gray-900">التعليقات (0)</h3>
                </div>
                <div className="bg-gray-50 p-8 rounded-[2rem] text-center border border-gray-100 border-dashed">
                  <p className="text-gray-500">لا توجد تعليقات بعد. كن أول من يعلق!</p>
                  <button className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-xl font-bold">إضافة تعليق</button>
                </div>
              </div>
            </div>

            {/* Sidebar Ads/Related */}
            <aside className="lg:w-80 space-y-8">
              <AdPlaceholder size="sidebar" />
              <div className="sticky top-24">
                <h4 className="text-lg font-bold mb-6 text-gray-900 pb-2 border-b-2 border-blue-600 inline-block">مقالات ذات صلة</h4>
                <div className="space-y-6">
                  {posts.filter(p => p.id !== id).slice(0, 3).map(relatedPost => (
                    <Link key={relatedPost.id} to={`/post/${relatedPost.id}`} className="block group">
                      <div className="aspect-video rounded-xl overflow-hidden mb-3">
                        <img src={relatedPost.image} alt={relatedPost.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                      </div>
                      <h5 className="font-bold text-sm text-gray-800 group-hover:text-blue-600 transition-colors line-clamp-2">
                        {relatedPost.title}
                      </h5>
                    </Link>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostDetail;
