
import React from 'react';
import { posts } from '../data/posts';
import PostCard from '../components/PostCard';
import AdPlaceholder from '../components/AdPlaceholder';
import { ArrowLeft, TrendingUp, Zap, Award } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  const featuredPost = posts[0];

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-700 to-blue-900 py-16 text-white rounded-b-[3rem] shadow-2xl overflow-hidden relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.1)_0%,_transparent_70%)] pointer-events-none opacity-50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row gap-12 items-center">
            <div className="flex-1 text-center md:text-right">
              <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-500/20 backdrop-blur-sm border border-blue-400/30 rounded-full text-sm font-semibold mb-6 animate-pulse">
                <Zap className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                آخر تحديثات التقنية لعام 2024
              </span>
              <h1 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
                ابدأ رحلتك في <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-100">عالم المعرفة</span> الرقمية
              </h1>
              <p className="text-lg md:text-xl text-blue-100 mb-8 max-w-2xl mx-auto md:mr-0 leading-relaxed font-light">
                نقدم لك أفضل الشروحات التقنية، طرق الربح من الإنترنت الموثوقة، وأحدث استراتيجيات التسويق الرقمي لتنمو في عملك.
              </p>
              <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                <button className="px-8 py-4 bg-white text-blue-700 font-bold rounded-2xl hover:shadow-xl hover:-translate-y-1 transition-all shadow-lg">تصفح المقالات</button>
                <button className="px-8 py-4 bg-blue-600/30 border border-blue-400/50 text-white font-bold rounded-2xl hover:bg-blue-600/50 transition-all">ابدأ الربح الآن</button>
              </div>
            </div>
            <div className="flex-1 w-full max-w-xl hidden lg:block">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-cyan-300 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                <img src={featuredPost.image} alt="Main" className="relative rounded-2xl shadow-2xl ring-1 ring-white/20" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4">
        {/* Ad Space - Top Banner */}
        <div className="mb-12">
          <AdPlaceholder size="banner" />
        </div>

        {/* Categories Pills */}
        <section className="flex flex-wrap gap-4 justify-center mb-16">
          {['تقنية', 'الربح من الإنترنت', 'تسويق', 'برمجة', 'ريادة أعمال'].map((cat) => (
            <Link 
              key={cat} 
              to={`/category/${cat}`}
              className="px-6 py-2.5 bg-white border border-gray-100 rounded-full text-sm font-bold text-gray-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 hover:shadow-lg hover:-translate-y-1 transition-all shadow-sm"
            >
              {cat}
            </Link>
          ))}
        </section>

        {/* Featured Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Feed */}
          <div className="lg:col-span-2 space-y-12">
            <div>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-black text-gray-900 flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-blue-600" />
                  آخر المقالات المنشورة
                </h2>
                <Link to="/all-posts" className="text-blue-600 font-bold text-sm flex items-center gap-1.5 hover:gap-3 transition-all">
                  عرض الكل <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {posts.map(post => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            </div>

            <AdPlaceholder size="banner" label="إعلان منتصف الصفحة" />

            <div>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-black text-gray-900 flex items-center gap-3">
                  <Award className="w-8 h-8 text-blue-600" />
                  قسم الربح من الإنترنت
                </h2>
                <Link to="/category/الربح من الإنترنت" className="text-blue-600 font-bold text-sm flex items-center gap-1.5 hover:gap-3 transition-all">
                  عرض الكل <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>
              <div className="space-y-6">
                {posts.slice(0, 2).map(post => (
                  <PostCard key={post.id} post={post} variant="list" />
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <aside className="space-y-10">
            <div className="bg-gray-50 p-6 rounded-3xl border border-gray-100">
              <h3 className="text-xl font-bold mb-4 text-gray-900">نشرة أخبارنا</h3>
              <p className="text-sm text-gray-500 mb-6">انضم إلى أكثر من 50,000 مشترك واحصل على أهم الأخبار والدروس أسبوعياً.</p>
              <form className="space-y-4">
                <input 
                  type="email" 
                  placeholder="بريدك الإلكتروني" 
                  className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
                <button className="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200">
                  اشترك الآن
                </button>
              </form>
            </div>

            <AdPlaceholder size="sidebar" />

            <div>
              <h3 className="text-xl font-bold mb-6 text-gray-900">المقالات الأكثر قراءة</h3>
              <div className="space-y-6">
                {posts.map((post, i) => (
                  <Link key={post.id} to={`/post/${post.id}`} className="flex gap-4 group">
                    <span className="text-3xl font-black text-gray-100 group-hover:text-blue-100 transition-colors">0{i+1}</span>
                    <div>
                      <h4 className="font-bold text-gray-800 text-sm group-hover:text-blue-600 transition-colors line-clamp-2 leading-relaxed">
                        {post.title}
                      </h4>
                      <span className="text-xs text-gray-400">{post.date}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default Home;
