
import React from 'react';

interface AdPlaceholderProps {
  size?: 'banner' | 'square' | 'sidebar';
  label?: string;
}

const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ size = 'banner', label = 'إعلان ممول' }) => {
  const sizeClasses = {
    banner: 'w-full h-32',
    square: 'w-full aspect-square',
    sidebar: 'w-full h-64 md:h-[400px]',
  };

  return (
    <div className={`bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center relative overflow-hidden group ${sizeClasses[size]}`}>
      <span className="absolute top-2 left-2 text-[10px] uppercase font-bold text-gray-400 bg-white/80 px-1.5 py-0.5 rounded border border-gray-200">
        {label}
      </span>
      <div className="text-center p-4">
        <p className="text-gray-400 text-sm font-medium mb-1">مكان الإعلان (Google AdSense)</p>
        <p className="text-gray-300 text-xs">قم بوضع شفرة الإعلان الخاصة بك هنا لاحقاً</p>
      </div>
      <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
        <span className="bg-white px-4 py-2 rounded shadow-sm text-xs font-semibold text-blue-600">
          Ads Area
        </span>
      </div>
    </div>
  );
};

export default AdPlaceholder;
