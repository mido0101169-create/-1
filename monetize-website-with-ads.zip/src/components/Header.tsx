
import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Menu, X, Bell } from 'lucide-react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <header className="bg-white border-b sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold text-blue-600 flex items-center">
            <span className="hidden md:inline">بوابة المعرفة</span>
            <span className="md:hidden">المعرفة</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex space-x-6 space-x-reverse text-gray-600 font-medium">
            <Link to="/" className="hover:text-blue-600">الرئيسية</Link>
            <Link to="/category/تقنية" className="hover:text-blue-600">تقنية</Link>
            <Link to="/category/الربح من الإنترنت" className="hover:text-blue-600">الربح من الإنترنت</Link>
            <Link to="/category/تسويق" className="hover:text-blue-600">تسويق</Link>
            <Link to="/about" className="hover:text-blue-600">من نحن</Link>
          </nav>

          {/* Search and Notifications */}
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Search className="w-5 h-5 text-gray-500" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full relative">
              <Bell className="w-5 h-5 text-gray-500" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <button 
              className="md:hidden p-2 hover:bg-gray-100 rounded-full"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {isOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-4 text-gray-600">
              <Link to="/" className="px-4 py-2 hover:bg-gray-50" onClick={() => setIsOpen(false)}>الرئيسية</Link>
              <Link to="/category/تقنية" className="px-4 py-2 hover:bg-gray-50" onClick={() => setIsOpen(false)}>تقنية</Link>
              <Link to="/category/الربح من الإنترنت" className="px-4 py-2 hover:bg-gray-50" onClick={() => setIsOpen(false)}>الربح من الإنترنت</Link>
              <Link to="/category/تسويق" className="px-4 py-2 hover:bg-gray-50" onClick={() => setIsOpen(false)}>تسويق</Link>
              <Link to="/about" className="px-4 py-2 hover:bg-gray-50" onClick={() => setIsOpen(false)}>من نحن</Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
