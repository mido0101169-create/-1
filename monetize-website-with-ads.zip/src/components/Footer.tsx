
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-8">
          {/* Brand and Description */}
          <div className="col-span-1 md:col-span-1">
            <h2 className="text-2xl font-bold text-white mb-4">بوابة المعرفة</h2>
            <p className="text-sm leading-relaxed text-gray-400">
              دليلك الشامل لتعلم أحدث التقنيات وكيفية الربح من الإنترنت بطرق مضمونة وعملية. نحن نهتم بتقديم محتوى عالي الجودة يفيدك في مسارك المهني والتقني.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4 underline decoration-blue-500 underline-offset-8 decoration-2">روابط سريعة</h3>
            <ul className="space-y-3">
              <li><Link to="/" className="hover:text-blue-400 transition-colors">الرئيسية</Link></li>
              <li><Link to="/about" className="hover:text-blue-400 transition-colors">من نحن</Link></li>
              <li><Link to="/contact" className="hover:text-blue-400 transition-colors">اتصل بنا</Link></li>
              <li><Link to="/privacy-policy" className="hover:text-blue-400 transition-colors">سياسة الخصوصية</Link></li>
              <li><Link to="/terms" className="hover:text-blue-400 transition-colors">شروط الاستخدام</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4 underline decoration-blue-500 underline-offset-8 decoration-2">أقسام الموقع</h3>
            <ul className="space-y-3">
              <li><Link to="/category/تقنية" className="hover:text-blue-400 transition-colors">تقنية</Link></li>
              <li><Link to="/category/الربح من الإنترنت" className="hover:text-blue-400 transition-colors">الربح من الإنترنت</Link></li>
              <li><Link to="/category/تسويق" className="hover:text-blue-400 transition-colors">تسويق</Link></li>
              <li><Link to="/category/برمجة" className="hover:text-blue-400 transition-colors">برمجة</Link></li>
            </ul>
          </div>

          {/* Newsletter & Contact */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4 underline decoration-blue-500 underline-offset-8 decoration-2">تواصل معنا</h3>
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-blue-500" />
                <span className="text-sm">contact@example.com</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-blue-500" />
                <span className="text-sm" dir="ltr">+20 123 456 789</span>
              </div>
            </div>
            <div className="flex gap-4">
              <a href="#" className="p-2 bg-gray-800 rounded-lg hover:bg-blue-600 transition-colors"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="p-2 bg-gray-800 rounded-lg hover:bg-blue-400 transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="p-2 bg-gray-800 rounded-lg hover:bg-pink-600 transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="p-2 bg-gray-800 rounded-lg hover:bg-red-600 transition-colors"><Youtube className="w-5 h-5" /></a>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-800 text-center text-sm text-gray-500">
          <p>© {new Date().getFullYear()} بوابة المعرفة. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
