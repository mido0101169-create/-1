
export interface Post {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  date: string;
  image: string;
}

export const posts: Post[] = [
  {
    id: '1',
    title: 'كيفية البدء في الربح من التدوين لعام 2024',
    excerpt: 'تعرف على الخطوات الأساسية لإنشاء مدونة ناجحة وتحقيق أرباح من خلال جوجل أدسينس.',
    content: 'التدوين ليس مجرد هواية، بل هو عمل تجاري متكامل... (نص المقال الكامل هنا)',
    category: 'الربح من الإنترنت',
    author: 'أحمد علي',
    date: '2024-05-20',
    image: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&q=80'
  },
  {
    id: '2',
    title: 'أفضل 10 أدوات للذكاء الاصطناعي للمبرمجين',
    excerpt: 'اكتشف كيف يمكن للذكاء الاصطناعي تسريع عملية التطوير وتحسين جودة الكود الخاص بك.',
    content: 'أصبح الذكاء الاصطناعي جزءاً لا يتجزأ من حياة المبرمج اليومية...',
    category: 'تقنية',
    author: 'سارة خالد',
    date: '2024-05-18',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80'
  },
  {
    id: '3',
    title: 'تحسين محركات البحث (SEO): دليل المبتدئين الشامل',
    excerpt: 'تعلم كيف تجعل موقعك يتصدر نتائج البحث في جوجل وتجذب آلاف الزوار مجاناً.',
    content: 'تحسين محركات البحث هو علم وفن في آن واحد...',
    category: 'تسويق',
    author: 'محمد محمود',
    date: '2024-05-15',
    image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800&q=80'
  }
];
